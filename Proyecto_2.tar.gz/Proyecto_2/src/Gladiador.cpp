#include "Gladiador.h"

Gladiador::Gladiador()
{
    //ctor
}

Gladiador::~Gladiador()
{
    //dtor
}
