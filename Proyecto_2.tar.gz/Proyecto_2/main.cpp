#include <iostream>

#include <allegro5/allegro.h>
#include <allegro5/allegro_primitives.h>
#include <allegro5/allegro_ttf.h>
#include <allegro5/allegro_font.h>

using namespace std;

int main()
{
    cout << "Hello world!" << endl;
    return 0;
}
